const express = require('express');
const cors = require('cors');
const customerRoutes = require('./routes/customerRoutes');
const errorHandler = require('./utils/errorHandler');
const path = require('path');
const prisma = require('./config/database');
require('dotenv').config();

const app = express();

// Middleware to parse JSON requests
app.use(express.json());
app.use(cors()); // Allows any origin
app.use(express.static(path.join(__dirname, 'public')));

// Mount the customer routes
app.use('/api', customerRoutes);

app.use(errorHandler);

// Check database connection
async function checkDatabaseConnection() {
  try {
    await prisma.$connect();
    console.log('Database connected successfully');
  } catch (error) {
    console.error('Error connecting to the database:', error.message);
    process.exit(1);
  }
}

// Start the server and check the database connection
app.listen(process.env.PORT, async () => {
  await checkDatabaseConnection();
  console.log(`Server is running on port ${process.env.PORT}`);
});
